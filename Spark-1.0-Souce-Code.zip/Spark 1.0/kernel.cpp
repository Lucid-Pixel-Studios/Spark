/*
this is the spark 1.0 kernel.
if you delete this, then the system cannot run.
deleting boot.bin will result in a unbootable system.
*/
inline unsigned char inb(unsigned short port) {
    unsigned char ret;
    asm volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

inline void outb(unsigned short port, unsigned char val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

inline void outw(unsigned short port, unsigned short val) {
    asm volatile ("outw %0, %1" : : "a"(val), "Nd"(port));
}

int cursor_pos = 0;
volatile char* video_memory = (volatile char*)0xB8000;
char cmd_buffer[64];
int cmd_idx = 0;
bool shift_pressed = false;
bool caps_lock = false;

void update_hw_cursor(int pos) {
    unsigned short p = pos / 2;
    outb(0x3D4, 0x0F); outb(0x3D5, (unsigned char)(p & 0xFF));
    outb(0x3D4, 0x0E); outb(0x3D5, (unsigned char)((p >> 8) & 0xFF));
}

void clear_screen() {
    for (int i = 0; i < 80 * 25 * 2; i += 2) {
        video_memory[i] = ' ';
        video_memory[i + 1] = 0x07; 
    }
    cursor_pos = 0;
    update_hw_cursor(cursor_pos);
}

void kprint(const char* s, char color = 0x07) {
    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] == '\n') {
            cursor_pos = ((cursor_pos / 160) + 1) * 160;
        } else if (s[i] == '\r') {
            cursor_pos = (cursor_pos / 160) * 160;
        } else {
            video_memory[cursor_pos++] = s[i];
            video_memory[cursor_pos++] = color;
        }
        if (cursor_pos >= 4000) cursor_pos = 0;
    }
    update_hw_cursor(cursor_pos);
}

int kstrcmp(const char* s1, const char* s2) {
    while (*s1 && (*s1 == *s2)) { s1++; s2++; }
    return *(unsigned char*)s1 - *(unsigned char*)s2;
}

void shutdown() {
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
}

char scancode_to_ascii(unsigned char scan, bool uppercase) {
    static const char low_map[] = {
        0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
        '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
        0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0, '\\',
        'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' '
    };
    static const char up_map[] = {
        0,  27, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b',
        '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',
        0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '\"', '~', 0, '|',
        'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0, '*', 0, ' '
    };
    return (scan < 58) ? (uppercase ? up_map[scan] : low_map[scan]) : 0;
}

extern "C" [[gnu::section(".text.kernel_main")]]
void kernel_main() {
    clear_screen();
    kprint("Spark(TM) 1.0 is made by Unified(TM)\r\n", 0x07); // I have to use (TM) to show a ™
    kprint("C:/>", 0x07);

    while (true) {
        if (inb(0x64) & 1) {
            unsigned char scan = inb(0x60);
            
            if (scan == 0x2A || scan == 0x36) shift_pressed = true;
            else if (scan == 0xAA || scan == 0xB6) shift_pressed = false;
            else if (scan == 0x3A) caps_lock = !caps_lock;
            
            else if (!(scan & 0x80)) {
                bool use_upper = shift_pressed ^ caps_lock;
                char c = scancode_to_ascii(scan, use_upper);

                if (c == '\n') {
                    cmd_buffer[cmd_idx] = '\0';
                    kprint("\r\n");

                    if (kstrcmp(cmd_buffer, "help") == 0) {
                        kprint("HELP      Display commands\r\nDIR       List files\r\nCLS       Clear screen\r\nREBOOT    Restart\r\nSHUTDOWN  Power off");
                    }
                    else if (kstrcmp(cmd_buffer, "dir") == 0) {
                        kprint(" Volume in drive C is SPARK\r\n Volume Serial Number is 1337-BEEF\r\n\r\n Directory of C:\\\r\n\r\n0 File(s)              0 bytes");
                    }
                    else if (kstrcmp(cmd_buffer, "cls") == 0) {
                        clear_screen();
                        cursor_pos = -160;
                    }
                    else if (kstrcmp(cmd_buffer, "reboot") == 0) outb(0x64, 0xFE);
                    else if (kstrcmp(cmd_buffer, "shutdown") == 0) shutdown();
                    else if (cmd_idx > 0) kprint("Bad command or file name");

                    kprint("\r\nC:/>");
                    cmd_idx = 0;
                } 
                else if (c == '\b' && cmd_idx > 0) {
                    cmd_idx--; cursor_pos -= 2;
                    video_memory[cursor_pos] = ' ';
                    update_hw_cursor(cursor_pos);
                } 
                else if (c >= ' ' && cmd_idx < 63) {
                    cmd_buffer[cmd_idx++] = c;
                    video_memory[cursor_pos++] = c;
                    video_memory[cursor_pos++] = 0x07;
                    update_hw_cursor(cursor_pos);
                }
            }
        }
    }
}