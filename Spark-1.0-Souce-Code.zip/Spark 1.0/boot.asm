[org 0x7C00]

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov ah, 0x02
    mov al, 16
    mov ch, 0
    mov cl, 2
    mov dh, 0
    mov dl, 0x80
    mov bx, 0x1000
    int 0x13
    jc disk_error

    cli
    lgdt [gdt_descriptor]

    mov eax, cr0
    or eax, 1
    mov cr0, eax

    jmp 0x08:protected_mode_entry

disk_error:
    mov si, err_msg
.err_loop:
    lodsb
    cmp al, 0
    je .halt
    mov ah, 0x0E
    int 0x10
    jmp .err_loop
.halt:
    hlt
    jmp .halt

[BITS 32]
protected_mode_entry:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x9FC00

    jmp 0x1000

[BITS 16]
gdt_start:
    dd 0x0
    dd 0x0

    dd 0x0000FFFF
    dd 0x00CF9A00

    dd 0x0000FFFF
    dd 0x00CF9200
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start  - 1
    dd gdt_start

msg db "Loading Kernel...", 0
err_msg db "disk read error!", 0
BOOT_DRIVE db 0

times 510 - ($-$$) db 0
dw 0xAA55