@echo off
set "MINGW_BIN=C:\msys64\ucrt64\bin"
set "LD_PATH=C:\msys64\ucrt64\bin\ld.exe"
set "OBJCOPY_PATH=C:\msys64\ucrt64\bin\objcopy.exe"

echo [1/6] Assembling boot.asm...
nasm -f bin boot.asm -o boot.bin

echo [2/6] Compiling kernel.cpp...
"%MINGW_BIN%\x86_64-w64-mingw32-g++.exe" -m32 -c kernel.cpp -o kernel.o -ffreestanding -O2 -fno-exceptions -fno-rtti -fno-pic

echo [3/6] Linking kernel...
"%LD_PATH%" -m i386pe -T linker.ld kernel.o -o kernel.tmp

echo [4/6] Extracting raw binary...
"%OBJCOPY_PATH%" -O binary kernel.tmp kernel.bin

echo [5/6] Creating Padded spark.img...
fsutil file createnew padding.bin 8192 > nul
cmd /c "copy /b boot.bin + kernel.bin + padding.bin spark.img"
del padding.bin

echo [6/6] launching QEMU...
cmd /c "qemu-system-x86_64 -drive format=raw,file=spark.img -vga std -boot menu=off"

echo.
echo DONE!
echo.
pause